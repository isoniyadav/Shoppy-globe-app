import React from 'react';
import { useDispatch } from 'react-redux';
import { removeFromCart } from '../redux/cartSlice';
import './CartItem.css';

function CartItem({ item }) {
  const dispatch = useDispatch();

  const handleRemoveFromCart = () => {
    dispatch(removeFromCart(item.id));
  };

  return (
    <div className="cart-item">
      <img src={item.image} alt={item.title} className="cart-item-image" />
      <div className="cart-item-details">
        <h3 className="cart-item-title">{item.title}</h3>
        <p className="cart-item-price">Price: ${item.price.toFixed(2)}</p>
        <div className="cart-item-actions">
          <button
            onClick={handleRemoveFromCart}
            className="remove-item-button"
          >
            Remove
          </button>
        </div>
      </div>
    </div>
  );
}

export default CartItem;
