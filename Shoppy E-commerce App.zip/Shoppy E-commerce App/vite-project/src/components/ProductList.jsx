import React, { useState } from 'react';
import ProductItem from './ProductItem';
import useFetchProducts from '../hooks/useFetchProducts';
import SearchBar from './SearchBar';
import './ProductList.css';  // Importing the CSS file

export const ProductList = () => {
  const { data, error } = useFetchProducts();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProducts = data?.filter(product => 
    product.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (error) {
    return <div>Error fetching products</div>;
  }

  return (
    <div className="product-list-container">
      <h1 className="product-list-title">Our Products</h1>
      <div className="search-bar-container">
        <SearchBar setSearchTerm={setSearchTerm} />
      </div>
      <div className="product-items">
        {filteredProducts?.map(product => (
          <ProductItem key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
