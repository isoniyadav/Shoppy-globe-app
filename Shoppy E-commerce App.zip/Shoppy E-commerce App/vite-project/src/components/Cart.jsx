// import React from 'react';
// import { useSelector, useDispatch } from 'react-redux';
// import CartItem from './CartItem';
// import './Cart.css';
// import { removeFromCart, incrementQuantity, decrementQuantity } from '../redux/cartSlice'; // import actions

// function Cart() {
//   const cartItems = useSelector((state) => state.cart.items);
//   const dispatch = useDispatch();

//   // Update the dispatch calls to use actions from cartSlice
//   const handleRemove = (id) => {
//     dispatch(removeFromCart(id)); // Dispatch the correct action
//   };

//   const handleIncrement = (id) => {
//     dispatch(incrementQuantity(id)); // Dispatch the correct action
//   };

//   const handleDecrement = (id) => {
//     dispatch(decrementQuantity(id)); // Dispatch the correct action
//   };

//   // Calculate the total price
//   const total = cartItems.reduce(
//     (sum, item) => sum + item.price * item.quantity,
//     0
//   );

//   // If the cart is empty, display a message
//   if (cartItems.length === 0) {
//     return <div className="cart-empty">Your cart is empty!</div>;
//   }

//   return (
//     <div className="cart-container">
//       <h1 className="cart-title">Your Cart</h1>
//       <div className="cart-items">
//         {cartItems.map((item) => (
//           <div key={item.id} className="cart-item">
//             <CartItem item={item} />
//             <div className="cart-item-actions">
//               <div className="cart-item-quantity">
//                 <button
//                   onClick={() => handleDecrement(item.id)}
//                   disabled={item.quantity === 1}
//                 >
//                   -
//                 </button>
//                 <span>{item.quantity}</span>
//                 <button onClick={() => handleIncrement(item.id)}>+</button>
//               </div>
//               <button
//                 onClick={() => handleRemove(item.id)}
//                 className="remove-item-btn"
//               >
//                 Remove
//               </button>
//             </div>
//           </div>
//         ))}
//       </div>
//       <div className="cart-total">
//         <h2>Total: ${total.toFixed(2)}</h2>
//       </div>
//     </div>
//   );
// }

// export default Cart;



import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import CartItem from './CartItem';
import './Cart.css';
import { removeFromCart, incrementQuantity, decrementQuantity } from '../redux/cartSlice'; // import actions

function Cart() {
  const cartItems = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();

  // Static exchange rate: 1 USD = 85 INR (You can update it to a real-time rate later)
  const exchangeRate = 85;

  const handleRemove = (id) => {
    dispatch(removeFromCart(id)); // Dispatch the correct action
  };

  const handleIncrement = (id) => {
    dispatch(incrementQuantity(id)); // Dispatch the correct action
  };

  const handleDecrement = (id) => {
    dispatch(decrementQuantity(id)); // Dispatch the correct action
  };

  // Calculate the total price in USD
  const totalUSD = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  // Convert the total price to INR
  const totalINR = totalUSD * exchangeRate;

  // If the cart is empty, display a message
  if (cartItems.length === 0) {
    return <div className="cart-empty">Your cart is empty!</div>;
  }

  return (
    <div className="cart-container">
      <h1 className="cart-title">Your Cart</h1>
      <div className="cart-items">
        {cartItems.map((item) => (
          <div key={item.id} className="cart-item">
            <CartItem item={item} />
            <div className="cart-item-actions">
              <div className="cart-item-quantity">
                <button
                  onClick={() => handleDecrement(item.id)}
                  disabled={item.quantity === 1}
                >
                  -
                </button>
                <span>{item.quantity}</span>
                <button onClick={() => handleIncrement(item.id)}>+</button>
              </div>
              <button
                onClick={() => handleRemove(item.id)}
                className="remove-item-btn"
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
      <div className="cart-total">
        <h2>Total: ₹{totalINR.toFixed(2)}</h2> {/* Display total in INR */}
      </div>
    </div>
  );
}

export default Cart;
