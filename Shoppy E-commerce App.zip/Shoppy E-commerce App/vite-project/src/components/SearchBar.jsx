import React from 'react';
import './SearchBar.css';  // Importing the CSS file

function SearchBar({ setSearchTerm }) {
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  return (
    <input
      type="text"
      className="search-bar"
      placeholder="Search products..."
      onChange={handleSearchChange}
    />
  );
}

export default SearchBar;
