import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import './ProductDetail.css'; // Importing the CSS file

function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch(`https://dummyjson.com/products/${id}`)
      .then(response => response.json())
      .then(data => setProduct(data))
      .catch(error => console.error(error));
  }, [id]);

  if (!product) return <div>Loading...</div>;

  return (
    <div className="product-detail-container">
      <div className="product-detail-header">
        <h1>{product.title}</h1>
        <p>{product.brand}</p>
        <p className="product-detail-price">Price: ${product.price}</p>
      </div>
      <div className="product-detail-description">
        <h2>Description:</h2>
        <p>{product.description}</p>
      </div>
      {product.image && (
        <img
          src={product.image}
          alt={product.title}
          className="product-detail-image"
        />
      )}
    </div>
  );
}

export default ProductDetail;
