import { useState, useEffect } from 'react';

function useFetchProducts() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('https://dummyjson.com/products')
      .then(response => response.json())
      .then(data => setData(data.products))
      .catch(error => setError(error));
  }, []);

  return { data, error };
}

export default useFetchProducts;
