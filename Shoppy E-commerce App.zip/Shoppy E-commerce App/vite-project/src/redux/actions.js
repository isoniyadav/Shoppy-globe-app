// export const addToCart = (product) => ({
//     type: 'ADD_TO_CART',
//     payload: product,
//   });
  
//   export const removeFromCart = (productId) => ({
//     type: 'REMOVE_FROM_CART',
//     payload: productId,
//   });
  
// redux/actions.js

import { addToCart, removeFromCart, incrementQuantity, decrementQuantity } from './cartSlice';

export const addItemToCart = (item) => {
  return (dispatch) => {
    dispatch(addToCart(item));
  };
};

export const removeItemFromCart = (id) => {
  return (dispatch) => {
    dispatch(removeFromCart(id));
  };
};

export const incrementItemQuantity = (id) => {
  return (dispatch) => {
    dispatch(incrementQuantity(id));
  };
};

export const decrementItemQuantity = (id) => {
  return (dispatch) => {
    dispatch(decrementQuantity(id));
  };
};
