import { configureStore } from '@reduxjs/toolkit';
import cartReducer from './cartSlice';  // Assuming you have cart slice

const store = configureStore({
  reducer: {
    cart: cartReducer,
  },
});

export default store;
