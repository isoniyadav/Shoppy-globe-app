// const initialState = {
//     items: [],
//   };
  
//   const cartSlice = (state = initialState, action) => {
//     switch (action.type) {
//       case 'ADD_TO_CART':
//         return { ...state, items: [...state.items, action.payload] };
//       case 'REMOVE_FROM_CART':
//         return { ...state, items: state.items.filter(item => item.id !== action.payload) };
//       default:
//         return state;
//     }
//   };
  
//   export default cartSlice;
  

// redux/cartSlice.js
import { createSlice } from '@reduxjs/toolkit';

// Initial state
const initialState = {
  items: [],
};

// Create slice for cart
const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const item = action.payload;
      const existingItem = state.items.find((i) => i.id === item.id);
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        state.items.push({ ...item, quantity: 1 });
      }
    },
    removeFromCart: (state, action) => {
      const id = action.payload;
      state.items = state.items.filter((item) => item.id !== id);
    },
    incrementQuantity: (state, action) => {
      const id = action.payload;
      const item = state.items.find((i) => i.id === id);
      if (item) item.quantity += 1;
    },
    decrementQuantity: (state, action) => {
      const id = action.payload;
      const item = state.items.find((i) => i.id === id);
      if (item && item.quantity > 1) item.quantity -= 1;
    },
  },
});

export const { addToCart, removeFromCart, incrementQuantity, decrementQuantity } = cartSlice.actions;
export default cartSlice.reducer;
